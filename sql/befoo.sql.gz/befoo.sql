-- MySQL dump 10.13  Distrib 5.6.26, for Linux (x86_64)
--
-- Host: localhost    Database: befoo
-- ------------------------------------------------------
-- Server version	5.6.26-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `resource`
--

DROP TABLE IF EXISTS `resource`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `resource` (
  `resource_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `resource_pid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '上级ID',
  `resource_type` enum('menu','action') NOT NULL COMMENT '资源类型 menu:菜单,action:功能',
  `resource_name` varchar(32) NOT NULL,
  `resource_key` varchar(32) NOT NULL,
  `resource_uri` varchar(64) NOT NULL DEFAULT '' COMMENT '资源地址',
  `menu_icon_class` varchar(64) NOT NULL DEFAULT '' COMMENT '菜单的图标样式',
  `enable` enum('Y','N') NOT NULL DEFAULT 'Y' COMMENT '是否启用',
  `login` enum('Y','N') NOT NULL DEFAULT 'Y' COMMENT '是否需要登录',
  `public` enum('Y','N') NOT NULL DEFAULT 'N' COMMENT '是否为公用资源',
  `menu_sort` int(10) NOT NULL DEFAULT '0' COMMENT '排序',
  `create_time` datetime NOT NULL COMMENT '创建时间',
  PRIMARY KEY (`resource_id`),
  UNIQUE KEY `uniq_resource_url` (`resource_uri`),
  UNIQUE KEY `uniq_resource_key` (`resource_key`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8 COMMENT='资源表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `resource`
--

LOCK TABLES `resource` WRITE;
/*!40000 ALTER TABLE `resource` DISABLE KEYS */;
INSERT INTO `resource` VALUES (1,0,'menu','首页','Admin-Index-index','/admin/index','fa fa-home','Y','Y','N',10,'2015-08-24 11:58:32'),(2,0,'menu','资源管理','Admin-Resource-manage','/admin/resource/manage','fa fa-cubes','Y','Y','N',20,'2015-06-22 18:23:58'),(3,0,'menu','用户管理','Admin-User-manage','/admin/user/manage','fa fa-user','Y','Y','N',90,'2015-08-24 11:58:36'),(4,3,'action','登录','Admin-User-login','/admin/user/login','','Y','N','Y',0,'2015-08-24 21:28:02'),(5,3,'action','登出','Admin-User-logout','/admin/user/logout','','Y','Y','Y',0,'2015-08-24 21:31:06'),(6,2,'action','获取资源列表数据','Admin-Resource-getpagedata','/admin/resource/getPageData','','Y','Y','N',0,'2015-08-27 21:31:51'),(7,2,'action','新增资源','Admin-Resource-addresource','/admin/resource/addResource','','Y','Y','N',0,'2016-01-24 20:43:29'),(8,2,'action','编辑资源','Admin-Resource-editresource','/admin/resource/editResource','','Y','Y','N',0,'2016-01-19 21:19:00'),(9,3,'action','获取用户列表数据','Admin-User-getpagedata','/admin/user/getPageData','','Y','Y','N',0,'2016-01-24 18:16:05'),(10,0,'menu','角色管理','Admin-Role-manage','/admin/role/manage','fa fa-group','Y','Y','N',30,'2016-01-24 18:50:18'),(11,10,'action','获取角色列表数据','Admin-Role-getpagedata','/admin/role/getPageData','','Y','Y','N',0,'2016-01-24 19:07:03'),(12,10,'action','新建角色','Admin-Role-addrole','/admin/role/addRole','','Y','Y','N',0,'2016-01-24 20:49:02'),(13,10,'action','编辑角色','Admin-Role-editrole','/admin/role/editRole','','Y','Y','N',0,'2016-01-24 21:46:00'),(14,10,'action','分配资源','Admin-Role-allocresource','/admin/role/allocResource','','Y','Y','N',0,'2016-01-24 21:59:53'),(15,3,'action','新增用户','Admin-User-adduser','/admin/user/addUser','','Y','Y','N',0,'2016-01-25 20:34:41'),(16,3,'action','编辑用户','Admin-User-edituser','/admin/user/editUser','','Y','Y','N',0,'2016-01-25 23:08:34');
/*!40000 ALTER TABLE `resource` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role`
--

DROP TABLE IF EXISTS `role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `role` (
  `role_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `role_name` varchar(32) NOT NULL COMMENT '角色名称',
  `role_key` varchar(32) NOT NULL COMMENT '角色key',
  `enable` enum('Y','N') NOT NULL DEFAULT 'Y' COMMENT '是否启用',
  `remark` varchar(200) NOT NULL DEFAULT '' COMMENT '备注',
  `create_time` datetime NOT NULL COMMENT '创建时间',
  PRIMARY KEY (`role_id`),
  UNIQUE KEY `uniq_role_key` (`role_key`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role`
--

LOCK TABLES `role` WRITE;
/*!40000 ALTER TABLE `role` DISABLE KEYS */;
INSERT INTO `role` VALUES (1,'超级管理员','admin','Y','','2015-08-24 11:58:23');
/*!40000 ALTER TABLE `role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role_resource_map`
--

DROP TABLE IF EXISTS `role_resource_map`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `role_resource_map` (
  `role_id` int(10) unsigned NOT NULL,
  `resource_id` int(10) unsigned NOT NULL,
  UNIQUE KEY `uniq_role_resource` (`role_id`,`resource_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role_resource_map`
--

LOCK TABLES `role_resource_map` WRITE;
/*!40000 ALTER TABLE `role_resource_map` DISABLE KEYS */;
INSERT INTO `role_resource_map` VALUES (1,1),(1,2),(1,3),(1,6),(1,7),(1,8),(1,9),(1,10),(1,11),(1,12),(1,13),(1,14),(1,15),(1,16);
/*!40000 ALTER TABLE `role_resource_map` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `user_id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '用户ID',
  `role_id` int(10) unsigned NOT NULL COMMENT '角色ID',
  `username` varchar(32) NOT NULL COMMENT '用户名',
  `password` varchar(32) NOT NULL COMMENT '加密的用户密码',
  `nickname` varchar(32) NOT NULL DEFAULT '' COMMENT '昵称',
  `enable` enum('Y','N') NOT NULL DEFAULT 'Y' COMMENT '是否启用',
  `admin` enum('Y','N') NOT NULL DEFAULT 'N' COMMENT '是否系统管理员',
  `login_times` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '登录次数',
  `last_login_time` datetime DEFAULT NULL COMMENT '最后登录时间',
  `last_login_ip` varchar(16) NOT NULL DEFAULT '' COMMENT '最后登录IP',
  `create_time` datetime NOT NULL COMMENT '创建时间',
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `uniq_username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,1,'admin','42b8780993b1dab414e07edaf5d0ebf0','admin','Y','N',12,'2016-01-25 20:11:35','10.236.118.37','2015-06-21 20:08:38');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-01-26  0:14:54
